# Makdisi School — QR Identification & Box Chat

Standalone mobile-first **Student Identification + Problems & Suggestions Box Chat** designed for scanning via a school QR code before publishing the full **School Plus** platform.

## 1. Upload to a New GitHub Repository

1. Go to GitHub and create a **new repository** (for example: `makdisi-box-chat`).
2. Upload all files inside this folder (including the hidden `.github/workflows/deploy.yml` folder), or push from VS Code:
   ```bash
   git init
   git add .
   git commit -m "Makdisi QR Box Chat"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/makdisi-box-chat.git
   git push -u origin main
   ```

## 2. Publish on GitHub Pages

1. Open your repository on GitHub → **Settings → Pages**.
2. Under **Build and deployment → Source**, select **GitHub Actions**.
3. Wait ~1 minute for the **Deploy Makdisi Box Chat to GitHub Pages** action to finish.
4. GitHub will give you a public URL like `https://YOUR_USERNAME.github.io/makdisi-box-chat/`.

## 3. Generate & Print Your School QR Code

1. Open your published GitHub Pages URL.
2. Click the **QR Code** button in the top bar.
3. Click **Print poster** or **Download PNG** to place the QR code around Makdisi School.

## 4. Optional: Connect Centralized Delivery / Live AI

- **Receiving student submissions centrally on static GitHub Pages**:  
  Set `VITE_SUBMISSION_WEBHOOK_URL` (for example, a free Formspree or Google Apps Script webhook URL) as a GitHub Repository Secret/Variable or in `.env` so every student submission from any phone goes straight to your Vice Representatives / Administration.
- **Full Gemini AI follow-up chat**:  
  Host `server.ts` on Render or Railway with `GEMINI_API_KEY` set, and set `VITE_CHAT_API_URL` to `https://your-api-url/api/assistant/report-chat`. Without a backend server, the app automatically runs in transparent **Guided Intake Mode**.
