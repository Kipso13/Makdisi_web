import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  // Relative base works on ANY GitHub Pages repository name (e.g. /makdisi-box-chat/)
  base: "./",
  plugins: [react(), tailwindcss()],
});
