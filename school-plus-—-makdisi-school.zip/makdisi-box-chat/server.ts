import "dotenv/config";
import express from "express";
import type { Request, Response } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, Type } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === "production";

interface ChatTurnInput {
  role: "user" | "assistant";
  content: string;
}

interface ReportChatBody {
  messages?: ChatTurnInput[];
  studentName?: string;
  className?: string;
  viceRepName?: string;
}

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
}

async function start() {
  const app = express();
  app.use(express.json({ limit: "1mb" }));

  // Allow GitHub Pages frontend to call this server if configured via VITE_CHAT_API_URL
  app.use((_req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    next();
  });

  app.options("/api/assistant/report-chat", (_req, res) => {
    res.sendStatus(204);
  });

  app.get("/api/health", (_req: Request, res: Response) => {
    res.json({ ok: true, app: "Makdisi Box Chat", aiConfigured: Boolean(getGeminiClient()) });
  });

  app.post("/api/assistant/report-chat", async (req: Request, res: Response) => {
    const body = (req.body || {}) as ReportChatBody;
    if (!Array.isArray(body.messages) || body.messages.length === 0) {
      res.status(400).json({ error: "Please include at least one message." });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({ error: "GEMINI_API_KEY is not configured on this server." });
      return;
    }

    const studentName = (body.studentName || "Student").slice(0, 80);
    const className = (body.className || "Makdisi School").slice(0, 80);
    const viceRepName = (body.viceRepName || "Class Vice Representative").slice(0, 80);

    const transcript = body.messages
      .slice(-16)
      .map((m) => `${m.role === "user" ? studentName : "Assistant"}: ${String(m.content).slice(0, 1200)}`)
      .join("\n");

    try {
      const response = await ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents: `Conversation transcript:\n${transcript}\n\nRespond clearly to the student and update the structured report fields.`,
        config: {
          systemInstruction: `You are the Makdisi School QR Box Chat Assistant helping ${studentName} (${className}) explain a problem or suggestion. Ask 1-2 short clarifying follow-up questions if details (where, when, or suggested fix) are missing; otherwise set readyToSubmit to true and summarize in 2-3 clear sentences for ${viceRepName}.`,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reply: { type: Type.STRING },
              readyToSubmit: { type: Type.BOOLEAN },
              suggestedTitle: { type: Type.STRING },
              category: { type: Type.STRING },
              urgency: { type: Type.STRING },
              summary: { type: Type.STRING },
            },
            required: ["reply", "readyToSubmit", "suggestedTitle", "category", "urgency", "summary"],
          },
        },
      });

      const parsed = JSON.parse((response.text || "{}").trim()) as Record<string, unknown>;
      res.json({
        reply: String(parsed.reply || "Could you share a bit more detail?"),
        readyToSubmit: Boolean(parsed.readyToSubmit),
        suggestedTitle: String(parsed.suggestedTitle || "Student Report").slice(0, 120),
        category: String(parsed.category || "Suggestion"),
        urgency: String(parsed.urgency || "Medium"),
        summary: String(parsed.summary || "").slice(0, 800),
      });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : "AI assistant failed.",
      });
    }
  });

  if (!IS_PROD) {
    const { createServer } = await import("vite");
    const vite = await createServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, "dist");
    app.use(express.static(distDir));
    app.get("*", (_req: Request, res: Response) => {
      const indexPath = path.join(distDir, "index.html");
      if (fs.existsSync(indexPath)) res.sendFile(indexPath);
      else res.status(404).send("Run npm run build first.");
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Makdisi Box Chat server running on http://localhost:${PORT}`);
  });
}

start().catch((err) => {
  console.error(err);
  process.exit(1);
});
